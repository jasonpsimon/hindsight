"""Fetch public, pinned FlashRank archives and verify every inference asset."""
import argparse
import asyncio
import hashlib
import json
from pathlib import Path
import stat
import zipfile

import aiohttp

ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--cache', type=Path, required=True)
parser.add_argument('--download-dir', type=Path, required=True)
args = parser.parse_args()
archives = {
    'ms-marco-TinyBERT-L-2-v2': '752eddf1c5ece3c5e6115e9ab52eb3b16436bbf9b3a091cbb62b5b8eadc47105',
    'ms-marco-MiniLM-L-12-v2': 'bdd3772b651ffc34f70e414049285bb55ccc6d1b8e29d0640f836d44f70ec77a',
}
pins = json.loads((ROOT/'model-pins.json').read_text())
async def main():
    args.cache.mkdir(parents=True, exist_ok=True)
    args.download_dir.mkdir(parents=True, exist_ok=True)
    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=600), trust_env=False) as session:
        for name, expected in archives.items():
            path = args.download_dir/(name+'.zip')
            url = f"https://huggingface.co/{pins['repository']}/resolve/{pins['revision']}/{name}.zip"
            async with session.get(url) as response:
                response.raise_for_status()
                with path.open('wb') as out:
                    async for chunk in response.content.iter_chunked(1024*1024):
                        out.write(chunk)
            assert hashlib.sha256(path.read_bytes()).hexdigest() == expected
            with zipfile.ZipFile(path) as archive:
                for entry in archive.infolist():
                    assert not Path(entry.filename).is_absolute() and '..' not in Path(entry.filename).parts
                    assert not stat.S_ISLNK(entry.external_attr >> 16)
                archive.extractall(args.cache)
            print(name, expected)
    for relative, expected in pins['files'].items():
        assert hashlib.sha256((args.cache/relative).read_bytes()).hexdigest() == expected, relative
    print('All pinned inference files verified')
asyncio.run(main())
