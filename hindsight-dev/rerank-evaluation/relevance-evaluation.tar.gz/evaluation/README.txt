Progressive reranking quality reproduction

Scope

This is a conditioned-candidate SciFact smoke. It includes every positive-qrel gold in the initial candidate pool. It does not measure retrieval or prove quality for every provider. Each stage uses the initial/global gold denominator. Gold missing at a later stage still counts against recall.

The rejected baseline is immutable. Its five queries are 1, 3, 5, 13 and 36. TinyBERT then MiniLM, limits 8/4, minimum macro recall 0.8, produces [0.8, 0.4] and must exit 1.

Those five queries became declared development data. One new development configuration was measured, MiniLM in both stages with limits 12/10. It passed [0.8, 0.8]. Repeating the same public model is deliberate here, to test conservative two-cut preservation, not to claim an efficient production cascade. Both stages really run inference and remove candidates.

Validation uses the next twenty positive-qrel test query IDs in numeric order, excluding development. Exact fixtures were persisted before validation inference. The 12/10 configuration was frozen after development and before the measured validation run. Both the first held-out measurement and the final-wheel replay returned [1.0, 1.0]. No validation-driven tuning occurred. The first measurement remains distinct from its replay.

The queries are 42, 48, 49, 50, 51, 53, 54, 56, 57, 70, 72, 75, 94, 99, 100, 113, 115, 118, 124 and 127. Each pool contains all gold plus twelve non-gold documents selected by unique query-term overlap, ties by corpus ID. Input sorts by corpus ID. Both 12 and 10 are below the stage input size for every validation query.

Files

The JSON fixtures contain only the selected public queries, candidate abstracts and qrels needed for these measurements, not the full corpus. Model weights, dataset archives, environment files and host logs are not redistributed. model-pins.json records the public model revision and exact inference-file hashes. Config files and reports record fixture/configuration hashes, ordered production events, actual cutoffs, mask losses, gold losses and early-loss metric controls. Controls deliberately remove gold in a synthetic event input; they are not model output. Every control rejects at both cuts.

Commands

Extract this archive in the artifacts directory, creating evaluation/. Use a new environment. Example with uv, executed from evaluation/:

  python3.11 -m venv .venv
  uv pip install --python .venv/bin/python ../api-slim/hindsight_api_slim-1.0.0-py3-none-any.whl ../dev/hindsight_dev-1.0.0-py3-none-any.whl -r requirements-evaluation.txt
  .venv/bin/python fetch_models.py --cache models --download-dir downloads
  OMP_NUM_THREADS=2 .venv/bin/python evaluate.py --fixture validation.json --config validation-config.json --model-cache models --output validation-reproduction.json
  OMP_NUM_THREADS=2 .venv/bin/python evaluate.py --fixture development.json --config development-config.json --model-cache models --output development-reproduction.json
  OMP_NUM_THREADS=2 .venv/bin/python evaluate.py --fixture rejected-baseline.json --config rejected-baseline.json --model-cache models --output rejected-reproduction.json

The validation and development commands should exit 0. The baseline command must write its report and exit 1. Do not reduce the guard, overwrite previous results or edit qrels to make a run pass. evaluate.py refuses an existing output path. A different platform can change real model scores; report any changed result rather than replacing the expected output.

Weights come from https://huggingface.co/prithivida/flashrank at revision 858a1ac046a05663a35367eac852d7f76feeefdd. fetch_models.py downloads revision-pinned archives, checks their SHA256 values, and checks all extracted inference files. Its download and extraction path was executed afresh during this repair. Production inference uses the shipped FlashRank factory, native pipeline, recall caller and DEBUG stage events, not reconstructed predictions.

Attribution and licenses

SciFact is from the Allen Institute for AI, https://github.com/allenai/scifact. The BEIR version is from the BEIR contributors, https://beir.ai, and the exact input archive is https://public.ukp.informatik.tu-darmstadt.de/thakur/BEIR/datasets/scifact.zip, SHA256 536e14446a0ba56ed1398ab1055f39fe852686ecad24a6306c80c490fa8e0165. The included upstream license distinguishes claims/annotations under CC BY 4.0 and Semantic Scholar S2ORC abstracts under ODC-By 1.0. The BEIR dataset card declares CC BY-SA 4.0. Preserve those attributions and terms when redistributing selected fixtures.

The quantized models are from Prithivi Da and the FlashRank contributors. Their repository card declares CC BY-SA 4.0 and requires attribution and a backlink, https://huggingface.co/prithivida/flashrank. The underlying sentence-transformers/cross-encoder MiniLM model card declares Apache 2.0, https://huggingface.co/cross-encoder/ms-marco-MiniLM-L12-v2. Included cards record these declarations. No weights are included.
