"""Execute fixed-global-denominator evaluation through the shipped factory/caller.

Install the final API wheel and hindsight-dev first. Weights stay outside this
portable asset directory; pass --model-cache with pinned FlashRank assets.
"""
import argparse
import asyncio
from dataclasses import asdict
import hashlib
import importlib
import importlib.metadata
import json
import logging
import os
from pathlib import Path
import sys

from hindsight_api.config import HindsightConfig
from hindsight_api.engine.factory_pipeline import build_encoder_from_config
from hindsight_api.engine.rerank_telemetry import RerankStageEvent
from hindsight_api.engine.search.reranking import CrossEncoderReranker
from hindsight_api.engine.search.types import MergedCandidate, RetrievalResult
from hindsight_dev.rerank_eval import evaluate_rerank_cutoff

parser = argparse.ArgumentParser()
parser.add_argument('--fixture', type=Path, required=True)
parser.add_argument('--config', type=Path, required=True)
parser.add_argument('--model-cache', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
assert not args.output.exists(), 'Preserve every experiment'
fixture_bytes, config_bytes = args.fixture.read_bytes(), args.config.read_bytes()
fixture, config = json.loads(fixture_bytes), json.loads(config_bytes)
assert config['minimum_macro_recall_each_cut'] == 0.8
pin_bytes = args.fixture.with_name('model-pins.json').read_bytes()
pins = json.loads(pin_bytes)
if 'model_pins_sha256' in config:
    assert hashlib.sha256(pin_bytes).hexdigest() == config['model_pins_sha256']
product_modules = [
    'hindsight_api.config', 'hindsight_api.engine.cross_encoder', 'hindsight_api.engine.memory_engine',
    'hindsight_api.engine.rerank_result', 'hindsight_api.engine.pipeline_rerank',
    'hindsight_api.engine.factory_pipeline', 'hindsight_api.engine.structured_failover',
    'hindsight_api.engine.search.reranking', 'hindsight_api.engine.search.reranking_pipeline',
    'hindsight_api.engine.rerank_telemetry', 'hindsight_dev.rerank_eval',
]
product_pins = {}
for name in product_modules:
    path = Path(importlib.import_module(name).__file__).resolve()
    assert path.is_relative_to(Path(sys.prefix).resolve()) and 'site-packages' in path.parts, (name, path)
    product_pins[name] = hashlib.sha256(path.read_bytes()).hexdigest()
for relative, expected in pins['files'].items():
    assert hashlib.sha256((args.model_cache/relative).read_bytes()).hexdigest() == expected
if 'fixture_sha256' in config:
    assert hashlib.sha256(fixture_bytes).hexdigest() == config['fixture_sha256']
events = []
class Capture(logging.Handler):
    def emit(self, record):
        message = record.getMessage()
        if message.startswith('rerank_stage '):
            events.append(RerankStageEvent.model_validate_json(message.removeprefix('rerank_stage ')))
logger = logging.getLogger('hindsight_api.engine.pipeline_rerank')
logger.setLevel(logging.DEBUG)
logger.addHandler(Capture())

async def main():
    os.environ['HINDSIGHT_API_RERANKER_PIPELINE'] = 'flashrank,flashrank'
    for index, (model, limit) in enumerate(zip(config['models'], config['limits']), 1):
        base = f'HINDSIGHT_API_RERANKER_PASS{index}_'
        os.environ[base+'FLASHRANK_MODEL'] = model
        os.environ[base+'FLASHRANK_CACHE_DIR'] = str(args.model_cache.resolve())
        os.environ[base+'LIMIT'] = str(limit)
    pipeline = build_encoder_from_config(HindsightConfig.from_env())
    await pipeline.initialize()
    rows = []
    controls = []
    for query in fixture['queries']:
        events.clear()
        candidates = [MergedCandidate(RetrievalResult(c['id'], c['text'], 'world'), 1.0) for c in query['candidates']]
        result = await CrossEncoderReranker(pipeline).rerank(query['query'], candidates)
        assert len(events) == 2
        assert events[0].output_ids == events[1].input_ids
        assert events[-1].output_ids == [r.id for r in result.results]
        reports = [asdict(evaluate_rerank_cutoff(gold_ids=set(query['gold_ids']), input_ids=e.input_ids,
                                              ranked_ids=e.ranked_ids, output_ids=e.output_ids, limit=e.limit)) for e in events]
        rows.append({'query_id': query['query_id'], 'gold_ids': query['gold_ids'], 'cutoffs': reports,
                     'events': [e.model_dump() for e in events], 'final_ids': [r.id for r in result.results]})
        ids = [c['id'] for c in query['candidates']]
        nongold = [i for i in ids if i not in query['gold_ids']]
        # Explicit metric-only adversary. Never substituted for model output.
        control = evaluate_rerank_cutoff(gold_ids=set(query['gold_ids']), input_ids=ids,
                                        ranked_ids=nongold, output_ids=nongold[:config['limits'][0]], limit=config['limits'][0])
        later = evaluate_rerank_cutoff(gold_ids=set(query['gold_ids']), input_ids=nongold[:config['limits'][0]],
                                      ranked_ids=nongold[:config['limits'][0]], output_ids=nongold[:config['limits'][1]], limit=config['limits'][1])
        for report in [control, later]:
            try:
                report.require_recall(0.8)
            except ValueError:
                pass
            else:
                raise AssertionError('early-loss control accepted')
        controls.append({'query_id': query['query_id'], 'rejected_each_cut': True, 'cutoffs': [asdict(control), asdict(later)]})
    macros = [sum(row['cutoffs'][i]['recall_after'] for row in rows)/len(rows) for i in range(2)]
    result = {'fixture_sha256': hashlib.sha256(fixture_bytes).hexdigest(), 'config_sha256': hashlib.sha256(config_bytes).hexdigest(),
              'config': config, 'rows': rows, 'macro_recall_after_each_cut': macros, 'minimum': 0.8,
              'accepted': all(value >= 0.8 for value in macros), 'controls': controls,
              'versions': {name: importlib.metadata.version(name) for name in ['flashrank', 'onnxruntime', 'numpy', 'hindsight-api-slim']},
              'installed_product_sha256_before_after': product_pins}
    for name, expected in product_pins.items():
        assert hashlib.sha256(Path(importlib.import_module(name).__file__).read_bytes()).hexdigest() == expected
    args.output.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({'accepted': result['accepted'], 'macro_recall': macros, 'queries': len(rows)}))
    return 0 if result['accepted'] else 1
raise SystemExit(asyncio.run(main()))
