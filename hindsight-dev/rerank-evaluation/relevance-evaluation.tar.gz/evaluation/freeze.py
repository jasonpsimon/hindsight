"""Freeze the chosen configuration before any validation inference."""
import datetime
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
result = json.loads((root/'development-result.json').read_text())
assert result['accepted'] and result['macro_recall_after_each_cut'] == [0.8, 0.8]
config = json.loads((root/'development-config.json').read_text())
config.update({'purpose': 'Prospective twenty-query validation. Chosen on declared development data only.',
               'fixture_sha256': sha(root/'validation.json'), 'model_pins_sha256': sha(root/'model-pins.json'),
               'development_result_sha256': sha(root/'development-result.json'),
               'frozen_at': datetime.datetime.now(datetime.timezone.utc).isoformat()})
path = root/'validation-config.json'
assert not path.exists()
path.write_text(json.dumps(config, indent=2)+'\n')
print(json.dumps({'configuration_sha256': sha(path), 'fixture_sha256': config['fixture_sha256'], 'frozen_at': config['frozen_at']}))
