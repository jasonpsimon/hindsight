"""Freeze SciFact inputs before held-out inference. Public data only."""
import csv
import hashlib
import io
import json
from pathlib import Path
import re
import zipfile

ROOT = Path(__file__).resolve().parent
archive = ROOT / 'scifact.zip'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(archive) == '536e14446a0ba56ed1398ab1055f39fe852686ecad24a6306c80c490fa8e0165'
with zipfile.ZipFile(archive) as z:
    corpus = {r['_id']: r for r in map(json.loads, z.read('scifact/corpus.jsonl').decode().splitlines())}
    queries = {r['_id']: r['text'] for r in map(json.loads, z.read('scifact/queries.jsonl').decode().splitlines())}
    qrels = list(csv.DictReader(io.StringIO(z.read('scifact/qrels/test.tsv').decode()), delimiter='\t'))
golds = {}
for row in qrels:
    if int(row['score']) > 0:
        golds.setdefault(row['query-id'], set()).add(row['corpus-id'])
eligible = sorted(golds, key=int)
assert eligible[:5] == ['1', '3', '5', '13', '36']
for split, ids in [('development', eligible[:5]), ('validation', eligible[5:25])]:
    records = []
    for qid in ids:
        gold = golds[qid]
        terms = set(re.findall(r'\w+', queries[qid].lower()))
        def overlap(cid):
            doc = corpus[cid]
            return len(terms & set(re.findall(r'\w+', (doc['title'] + ' ' + doc['text']).lower())))
        negatives = sorted((cid for cid in corpus if cid not in gold), key=lambda cid: (-overlap(cid), cid))[:12]
        candidates = sorted(gold | set(negatives))
        records.append({'query_id': qid, 'query': queries[qid], 'gold_ids': sorted(gold),
                        'candidates': [{'id': cid, 'text': corpus[cid]['title'] + '\n' + corpus[cid]['text']} for cid in candidates]})
    fixture = {'split': split, 'selection': 'Numeric positive-qrel SciFact test IDs. First five are development; next twenty are prospective validation. All gold plus twelve non-gold by unique-term overlap, ties by corpus ID. Input by corpus ID.',
               'dataset_url': 'https://public.ukp.informatik.tu-darmstadt.de/thakur/BEIR/datasets/scifact.zip',
               'dataset_sha256': sha(archive), 'queries': records,
               'scope': 'Conditioned reranking smoke with all qrels gold initially retrieved. Not end-to-end retrieval or an all-provider guarantee.'}
    path = ROOT / (split + '.json')
    assert not path.exists(), 'Never overwrite a frozen fixture'
    path.write_text(json.dumps(fixture, indent=2) + '\n')
    print(split, ids, sha(path))
model_cache = ROOT.parent / 'cache/models'
pins = {str(p.relative_to(model_cache)): sha(p) for p in model_cache.rglob('*') if p.is_file() and '__MACOSX' not in p.parts}
(ROOT / 'model-pins.json').write_text(json.dumps({'repository': 'prithivida/flashrank', 'revision': '858a1ac046a05663a35367eac852d7f76feeefdd', 'files': pins}, indent=2) + '\n')
